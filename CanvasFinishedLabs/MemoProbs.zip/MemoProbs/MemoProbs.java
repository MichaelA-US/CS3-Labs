import java.util.*;
/**
 * This class implements memo problems to practice the concept of memoization a process
 * to find solutions to sub problems that are cached and re calculated.
 * @author Michael
 *
 */
public class MemoProbs
{
	public static HashMap<Integer, Integer> mapCoins; //minCoins
	public static int[] minCoins = {0,1};	//minCoins
	public static int R;
	public static int C;
	public static int[][] paths;
	static String str;
	static int count;
	static Map<Pair, Integer> pascal = new HashMap<>();
	public static void main(String args[])
	{
		mapCoins = new HashMap<Integer, Integer>();
		mapCoins.put(0, 0);
		mapCoins.put(1, 1);
		System.out.print("printPascalRow(9) >>> ");
		printPascalRow(9);
		System.out.println("printPascalRow(40) >>> " + "\n");
		printPascalRow(40);
		System.out.println("numPaths(new int[2][4] >>> " + numPaths(new Integer[2][4]) + "\n");
		System.out.println("numPaths(new int[3][4] >>> " + numPaths(new Integer[3][4]) + "\n");
		System.out.println("numPaths(new int[20][12] >>> " + numPaths(new Integer[20][12]) + "\n");
		System.out.println("MAP: minCoinsMap(11, new int[] {9, 6, 5, 1}) >>> " + minCoinsMap(11, new int[] {9, 6, 5, 1}) + "\n");
		System.out.println("MAP: minCoinsMap(1000, new int[] {12, 8, 5, 2, 1}) >>> " + minCoinsMap(1000, new int[] {12, 8, 5, 2, 1}) + "\n");
		System.out.println("ARRAY: minCoinsArray(11, new int[] {9, 6, 5, 1})>>> " + minCoinsArray(11, new int[] {9, 6, 5, 1}) + "\n");
		System.out.println("ARRAY: minCoinsArray(1000, new int[] {12, 8, 5, 2, 1}) >>> " + minCoinsArray(1000, new int[] {12, 8, 5, 2, 1}) + "\n");
		
	}
	//Pascal Triangles
	/**
	 * Gets the val in the Pascal's triangle at the row and col using
	 * memoization to save time by onling calculating a given location vals one time
	 * to speed it up
	 * @param row - row of triangle
	 * @param col - col of triangle
	 * @return the vals of the last pascal triangle row
	 */
	public static int pascal(int row, int col)
	{
			Pair n = new Pair(row, col);
			if(col == 0 || col == row)
			{
				return 1;
			}
			if(pascal.containsKey(n))
			{
				return pascal.get(n);
			}
			else
			{
				int result = pascal(row - 1, col - 1) + pascal(row - 1, col);
				pascal.put(n, result);
				return Math.abs(result);
			}
	}
	/**
	 * Prints the the last row of pascal
	 * @param row - prints pascal row
	 */
	public static void printPascalRow(int row)
	{
		str = "";
		count = row;
	            for (int c = 0; c <= row; c++) 
	            {
	                str += "" + (pascal(row, c) + " ");
	            }
	            str += "\n";
		System.out.println(str);
	}
	//Pascal Triangle
	
	//Min Paths-----
	/**
	 * Recursively search the paths for each through the 2d array for the left
	 * right and down the path
	 * @param paths -  the paths
	 * @return the num of unique ways to get from 0 0 to R and C
	 */
	private static int numPaths(Integer[][] paths) 
	{
		int r = paths.length; 	int c = paths[0].length;

		for (int i = 0; i < r; i++)
		{
			paths[i][0] = 1;
			for (int j = 0; j < c; j++)
			{
				paths[0][j] = 1;
			}
		}
		for (int i = 1; i < r; i++)
		{
			for (int j = 1; j < paths[i].length; j++)
			{
				paths[i][j] = paths[i - 1][j] + paths[i][j - 1];
			}
		}
		return paths[r - 1][c - 1];
	}
	//Min Paths-----
	//Min Coins----
	/**
	 * Calculate the min number of coins in a array to make exact
	 * change for the passed total.
	 * @param total - the total 
	 * @param coins - coins avaiable
	 * @return min num of c oins to make exact change for the total
	 */
	public static int minCoinsArray(int total, int[] coins) 
	{
		minCoins = new int[total+1];
		for(int i = 2; i < total+1; i++) 
		{
			minCoins[i] = -1;
		}
		minCoinsArrayHelper(total, coins);
		return minCoins[total];
	}
	/**
	 * Calculates min number of coins to make exact change through
	 * backtracking through the array
	 * @param total - curr total
	 * @param coins - coins to use
	 * @return min num of coins with curr total to make change
	 */
	private static int minCoinsArrayHelper(int total, int[] coins) 
	{
		if(minCoins[total] != -1) 
		{
			return minCoins[total]; 
		}
		int numCoins = Integer.MAX_VALUE;
		for(int i = 0; i < coins.length; i++) 
		{
			int r = total - coins[i];
			int coinVal = Integer.MAX_VALUE;
			if(r >= 0) 
			{
				coinVal = minCoinsArrayHelper(coinVal, coins) + 1;
			}
			if(coinVal < numCoins) 
			{
				numCoins = coinVal;
			}
		}
		minCoins[total] = numCoins;
		return numCoins;
	}
	/**
	 * Calculate the min number of coins in a array to make exact
	 * change for the passed total. Uses a map to speed up the
	 * process
	 * @param total - the total 
	 * @param coins - coins avaiable
	 * @return min num of c oins to make exact change for the total
	 */
	public static int minCoinsMap(int total, int[] coins) 
	{	
		minCoinsMapHelper(total, coins);
		return mapCoins.get(total);
	}
	/**
	 * Calculates min number of coins to make exact change through
	 * backtracking through the array uses a map to remember the positions
	 * with the keys so we don't have to go over previously indexed spots
	 * which speeds up the process
	 * @param total - curr total
	 * @param coins - coins to use
	 * @return min num of coins with curr total to make change
	 */
	private static int minCoinsMapHelper(int total, int[] coins) 
	{
		if(mapCoins.containsKey(total)) 
		{
			return mapCoins.get(total); 
		}
		int minCoins = Integer.MAX_VALUE;
		for(int i = 0; i < coins.length; i++) 
		{
			int r = total - coins[i];
			int coinVal = Integer.MAX_VALUE;
			if(r >= 0)
			{
				coinVal = minCoinsMapHelper(r, coins) + 1;
			}
			if(coinVal < minCoins) 
			{
				minCoins = coinVal;
			}
		}
		mapCoins.put(total, minCoins);
		return minCoins;
	}
	//Min Coins----
}
/**
 * Pair class for pascal with rows and cols
 * @author Michael
 *
 */
class Pair 
{
	int r, c;
	/**
	 * Basic constructor to initalize vars
	 * @param r - rows
	 * @param c - cols
	 */
	public Pair(int r, int c)
	{
		this.r = r;
		this.c = c;
	}
	/**
	 * Overriden equals method to compare borth rows and cols
	 * @return true or false if equal or not
	 */
	@Override
	public boolean equals(Object pair) 
	{
		Pair p = (Pair) pair;
		return p.r == r && p.c == c;
	}
	/**
	 * hashcode method that subtract rows from cols and just modulus it by 10
	 */
	@Override
	public int hashCode() 
	{
		return (r - c) % 10;
	}
	/**
	 * prints rows and cols
	 * @return string representation of rows and cols
	 */
	@Override
	public String toString() 
	{
		return r + " " + c;
	}
}
