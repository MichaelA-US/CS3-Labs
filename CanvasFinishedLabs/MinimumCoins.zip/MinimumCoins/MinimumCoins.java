import java.util.*;
import java.io.*;
/**
 * This class implements a method that takes in an array of vals and a target value and checks the minimum value
 * of combinations of the coins to obtain thus value (Uses dynamic programming)
 * @author Michael
 *
 */
public class MinimumCoins 
{
	public static void main(String[] args) throws IOException
	{
		Scanner scan = new Scanner(new File("coins.dat"));
		int num = scan.nextInt();
		for(int i = 0; i < num; i++)
		{
			int targetVal = scan.nextInt();
			scan.nextLine();
			String[] line = scan.nextLine().split(" ");
			int[] vals = Arrays.stream(line).mapToInt(Integer::parseInt).toArray(); //maps array to ints in 1 line of code (source: google)
			
			minCoins(vals, vals.length, targetVal);
		}
	}
	/**
	 * Min coins method that creates a table that stores the min num of coins for the target value at the target value
	 * by starting at the infinity value and compares all min coins smaller than the target value and stores that into the
	 * table of curr mins
	 * @param vals - the array of coin values
	 * @param len - the length of the coins vals
	 * @param targVal - the target value we are supposed to hit
	 */
	public static void minCoins(int[] vals, int len, int targVal)
	{
        int table[] = new int[targVal + 1]; 
        Arrays.fill(table, (int) Double.POSITIVE_INFINITY); table[0] = 0;
        
        
        for (int i = 1; i <= targVal; i++) 
        { 
            for (int j = 0; j < len; j++) 
            {
            	if (vals[j] <= i) 
            	{ 
            	    int min = table[i - vals[j]]; 
            	    int currMin = min + 1;
            	    
            		if (min != (int) Double.POSITIVE_INFINITY && currMin < table[i]) 
            		{
                       table[i] = currMin; 
            		}
            	} 
            }
              
        } 
       if(table[targVal] == (int) Double.POSITIVE_INFINITY) //Checks if impossible
       {
    	   System.out.println("Not possible with the given denominations"); //impossible
       }
       else
       {
    	   System.out.println(table[targVal]); //is possible
       }
	}
}
