/**
 * This class runs the test cases for my MinHeapGeneric class to ensure that
 * everything is working properly
 * @author Michael
 *
 */
public class GenericRunner
{
	public static void main(String[] args) 
	{
		MinHeapGeneric<Integer> heap = new MinHeapGeneric<Integer>();
		
		int[] nums = {8, 42, 35, 4, -1, 99, 76, 20};
		
		for (int i = 0; i < nums.length; i++) 
			heap.insert(nums[i]);
		
		System.out.println("Heap toString: " + heap);
		System.out.println("\ninitial state of the heap");
		heap.display();
		
		heap.insert(36); System.out.println("inserting 36 into the heap...");
		heap.display();
		
		heap.insert(3); System.out.println("inserting 3 into the heap...");
		heap.display();
		
		System.out.println("Pop min (new min at root) = " + heap.popMinimum());
		heap.display();

		System.out.println("Peek min (shouldn't change) = " + heap.peekMinimum());
		heap.display();
		
		heap = new MinHeapGeneric(); 
		heap.insert(2);
		heap.insert(5);
		heap.insert(6);
		heap.insert(7);
		heap.insert(456);
		heap.insert(23);
		heap.insert(88);
		heap.display();
	}
}
