
/**
 * This class implenets a Minheap which is essentialy a complete binary tree using
 * an array
 * @author Michael
 *
 */
public class MinHeap {

    public Integer[] heap;
    private int size;
    private static final int DEFAULT_CAPACITY = 8;
    /**
     * Default constructor that initalizes a new heap at the default capacity +1
     */
    public MinHeap()
    {
       heap = new Integer[DEFAULT_CAPACITY + 1];
    }
    /**
     * Varargs constructor that is passed an inital amount of vals and
     * constructs the heap using the heapify method
     * @param vals - the vals to store into the heap
     */
    public MinHeap(Integer... vals)
    {
        heap = new Integer[vals.length+1];
        for (int i = 0; i < vals.length; i++)
        {
            heap[i + 1] = vals[i];
        }
        buildHeap();
    }
    /**
     * Loops through the heap length / 2 and calls the heapify method
     * (I used slides pseudocode for this)
     */
    private void buildHeap() 
    {
		for(int i = heap.length/2; i >= 1; i--) 
		{
			heapify(i);
		}
    }
    /**
     * Heapify method that checks if the index has a left child and right child and changes
     * the temp value to it then recursively calls itself till it becomes a minheap
     * (I used slides pseudocode for this)
     * @param index
     */
    private void heapify(int index)
    {
		int temp = index;
		if(inBounds(getLeftChildIndex(index)) && heap[(index * 2)] != null && getLeftChildIndex(index) < heap[temp]) 
		{
			temp = getLeftChildIndex(index);
		}
		if(inBounds(getRightChildIndex(index)) && heap[(index * 2) + 1] != null && getRightChildIndex(index) < heap[temp]) 
		{
			temp = getRightChildIndex(index);
		}
		if(temp != index)
		{
			swap(index, temp);
			heapify(temp);
		}
	}
    /**
     * In bounds method that checks if the index is actually within the size of the heap
     * @param index - the index to check
     * @return true or false depending on if its bigger or smaller
     */
	private boolean inBounds(int index)
	{
		return index < size;
	}
	/**
	 * Takes in a value and puts it into the heap makes sure to double the size of 
	 * the heap if about to be full.
	 * @param num - num to insert
	 */
    public void insert(int num) 
    {
        if (size == heap.length - 1) 
        {
        	doubleCapacity();
        }
        int temp = size + 1;
        heap[temp] = num;
        bubbleUp(temp);
        size++;
    }
    /**
     * Finds the min val and removes it from the actual heap and make sure to resort the
     * tree to be a suitable heap once more
     * @return the min val 
     */
    public int popMinimum() 
    {
        int pop = peekMinimum();
        int lastVal = heap[size];
        heap[size] = null;
        size--;
        heap[1] = lastVal;
        siftDown(1);
        return pop;
    }
    /**
     * Gets the min value in the heap
     * @return the min val
     */
    public int peekMinimum() 
    {
        return heap[1];
    }
    /**
     * Returns the size of the heap
     * @return the size
     */
    public int getSize() 
    {
        return size;
    }
    /**
     * Checks if the heap is empty depending on its size
     * @return (true or false) depending on if empty or not
     */
    public boolean isEmpty() 
    {
        return size == 0;
    }
    /**
     * Returns the left child of the index given
     * @param index - the index to check for
     * @return the left child
     */
    private int getLeftChildIndex(int index) 
    {
        return index * 2;
    }
    /**
     * Returns the right child of the index given
     * @param index - the index to check for
     * @return the right child
     */
    private int getRightChildIndex(int index)
    {
        return index * 2 + 1;
    }
    /**
     * Returns the parent child of the index given
     * @param index - the index to check for
     * @return the parent child
     */
    private int getParentIndex(int index) 
    {
        return index / 2;
    }
    /**
     * Doubles the size of the heap
     */
    private void doubleCapacity() 
    {
        Integer[] dubArr = new Integer[heap.length * 2];
        for (int i = 1; i < heap.length; i++) 
        {
        	dubArr[i] = heap[i];
        }
        heap = dubArr;
    }
    /**
     * Recursively adds the value added to the heap to its place in the heap
     * @param index - the index to check
     */
    private void bubbleUp(int index) {
        if (heap[getParentIndex(index)] == null) 
        {
        	return;
        }
        if (heap[index] < heap[getParentIndex(index)])
        {
            swap(index, getParentIndex(index));
            bubbleUp(getParentIndex(index));
        }
    }
    /**
     * Recursively sorts the heap so that when a value is passed down it will move its
     * way down through the heap to its correct index
     * @param index - the curr index to check for
     */
    private void siftDown(int index) {
        if (heap[getLeftChildIndex(index)] == null && heap[getRightChildIndex(index)] == null) 
        {
        	return;
        }
        if (heap[getLeftChildIndex(index)] != null && heap[getRightChildIndex(index)] == null) 
        {
            if (heap[index] > heap[getLeftChildIndex(index)])
            {
                swap(index, getLeftChildIndex(index));
            }
            return;
        } else if (heap[getLeftChildIndex(index)] == null && heap[getRightChildIndex(index)] != null)
        {
            if (heap[index] > heap[getRightChildIndex(index)])
            {
                swap(index, getRightChildIndex(index));
            }
            return;
        }
        if (heap[index] > Math.min(heap[getLeftChildIndex(index)], heap[getRightChildIndex(index)])) 
        {
        	int sIndex = 0;
           if(heap[getLeftChildIndex(index)] < heap[getRightChildIndex(index)])
           {
        	   sIndex = getLeftChildIndex(index);
           }
           else
           {
        	   sIndex = getRightChildIndex(index);
           }
            swap(index, sIndex);
            siftDown(sIndex);
        }
    }
    /**
     * Swaps one index with the other
     * @param index1 - index1 to swap
     * @param index2 - index2 to swap with index1
     */
    private void swap(int index1, int index2)
    {
        int temp = heap[index2];
        heap[index2] = heap[index1];
        heap[index1] = temp;
    }
//Given-----------------------------------------------------------------------
    @Override
    public String toString() {
        String output = "";
        for (int i = 1; i <= getSize(); i++)
            output += heap[i] + ", ";
        return output.substring(0, output.lastIndexOf(","));
    }

    public void display() {
        int nBlanks = 32, itemsPerRow = 1, column = 0, j = 1;
        String dots = "...............................";
        System.out.println(dots + dots);
        while (j <= this.getSize()) {
            if (column == 0)
                for (int k = 0; k < nBlanks; k++)
                    System.out.print(' ');
            System.out.print((heap[j] == null) ? "" : heap[j]);
            if (++column == itemsPerRow) {
                nBlanks /= 2;
                itemsPerRow *= 2;
                column = 0;
                System.out.println();
            } else
                for (int k = 0; k < nBlanks * 2 - 2; k++)
                    System.out.print(' ');
            j++;
        }
        System.out.println("\n" + dots + dots);
    }
  //Given-----------------------------------------------------------------------
}
