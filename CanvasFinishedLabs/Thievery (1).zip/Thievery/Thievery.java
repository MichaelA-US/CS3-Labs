import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Arrays;
/**
 * This class implements a  a weight limit W that you can burgle one time, and a house that contains various items
 * with weights w values v, and makes an algorithm that will net you the most possible money given your weight limit.
 * @author Michael
 *
 */
public class Thievery 
{
	static String[] word;
	static int[] weights;
	static int[] vals;
	static int[] values;
	static int len;
	public static void main(String[] args) throws FileNotFoundException 
	{
		Scanner scan = new Scanner(new File("Knapsack.dat"));
		int n = scan.nextInt(); 
		scan.nextLine();
		for(int i = 0; i < n; i++)
		{
			
			scan.nextLine();
			int items = scan.nextInt(); scan.next(); int w = scan.nextInt(); scan.nextLine(); scan.nextLine();
			//System.out.println(items);
			//System.out.println(w);
			vals = new int[items];
			values = new int[items];
			weights = new int[items];
			
			word = scan.nextLine().split(", ");
			//System.out.println(Arrays.toString(word));
			for(int j = 0; j < items; j++) 
			{
				weights[j] = Integer.parseInt(word[j]);
				//System.out.println(weights[j]);
			}
			word = scan.nextLine().split(", ");
			for(int k = 0; k < items; k++) 
			{
				vals[k] = Integer.parseInt(word[k]);
				values[k] = Integer.parseInt(word[k]);
				//System.out.println(values[k]);
			}
			Integer[][] dp = new Integer[items+1][w+1];
			len = dp.length;
			System.out.println("-Max Weight: " + w);
			System.out.println("-Max Value: " + (maxValue(dp)));
			System.out.println("\n");
		}
	}
	/**
	 * Max value problem that takes in the array of both items and weights and constructs a knapsack
	 * algo with dynamic programming to find the maximum value without exceeding the max weight.
	 * @param maxWeights - the 2D array of items and weights
	 * @return the value at the 2d array that is the max val possible
	 */
	 public static int maxValue(Integer[][] maxWeights) 
	 {
	        for (int i = 0; i < len; i++) //looping through 2D array
	        {
	            for (int j = 0; j < maxWeights[i].length; j++) 
	            {
	                if (i == 0) //if on first iteration
	                {
	                	maxWeights[i][j] = 0; //start at 0
	                    continue;
	                }
	                if (weights[i-1] <= j) //if the weight at the previous is less than the current index
	                {
	                    int take = values[i - 1] + maxWeights[i - 1][j - weights[i - 1]]; //take the previous item and the max weight
	                    maxWeights[i][j] = Math.max(take, maxWeights[i-1][j]); //get the max value between the previous item and weight with the other previous
	                } 
	                else //otherwise
	                {
	                	maxWeights[i][j] = maxWeights[i-1][j]; //change index to the prev item with the curr weight
	                }
	            }
	        }
	        return maxWeights[len-1][maxWeights[0].length - 1]; //return last val
	 }
	/**
-Max j: 10
-Max Value: 26


-Max j: 850
-Max Value: 7534


-Max j: 100000
-Max Value: 148761
	 */
}