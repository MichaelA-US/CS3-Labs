import java.util.*;
import java.io.*;
/**
 * This class implements a dp bottom top approach to count number of possible ways to climb steps with 3 2 or 1
 * @author Michael
 */
public class ClimbStairs 
{
    static int count;
    static int[] sArr = {0, 1, 2};
    public static void main(String args[]) throws FileNotFoundException
    {
        /**(dat file)
        5
        1
        3
        7
        20
        27
         */
        Scanner scan = new Scanner(new File("steps.dat"));
        int num = scan.nextInt();

        for(int i = 0; i < num; i++)
        {
            int n = scan.nextInt();
            int[] sArr = new int[n + 3];
            sArr[0] = 1;sArr[1] = 1;sArr[2] = 2; 
            System.out.println(climbStairsHelper(sArr, n));
            count = 0;
        }
    }
/**
 * Edited climbsteps method that implements dynamic programming and a bottom top approach to iteravely go through an array
 * of size steps and store in the current amount of steps for each approach of 3, 2, or 1
 * @param stepsArr - the array that contains the size of steps and allocates the current step values
 * @param steps - the amount of steps we are going to go up on a stair
 * @return the amount of ways to climb that given amount of steps
 */
    public static int climbStairsHelper(int[] stepsArr, int steps)
    {
        if(steps == 0)
        {
            return sArr[0];
        }
        else
        {
        for (int i = 3; i <= steps; i++) 
        {
            stepsArr[i] = stepsArr[i - 3] + stepsArr[i - 2] + stepsArr[i - 1]; 
        }
    }
        return stepsArr[steps]; 
        
    }
}
