import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

/**
 * @author Michael Ades
 * This class implements multiple methods in order to solve a word
 * chain in an efficient way.
 */
public class WordLadder
{
    private Queue<Stack<String>> words;
    private HashSet<String> dictionary;
    private HashSet<String> foundWords;

    /**
     * Basic constructor that takes in the dictionary and input to store
     * it into two hashsets of information
     * @throws FileNotFoundException
     */
    public WordLadder() throws FileNotFoundException
    {
        words = new LinkedList();
        dictionary = new HashSet();
        foundWords = new HashSet();

        Scanner in = new Scanner(new File("input.txt"));
        Scanner dict = new Scanner(new File("dictionary.txt"));

        while(dict.hasNext()) //Going through all the text and adding to hashset
        {
            dictionary.add(dict.next());
        }

        while(in.hasNext()) //Going through all the input and getting its path through the algorithm
        {
            System.out.println(getPath(in.next(), in.next()));
        }
    }

    /**
     * Takes in a word and goes through all possible combinations
     * of changing each letter in the word. Then checks if it is in
     * the dictionary and adds it to the stack and the foundWords to try
     * @param word - the word to go through
     * @return the stack with the words found
     */
    public Stack<String> findWords(String word)
    {
        Stack<String> tempWords = new Stack();

        for(int i = 0; i < word.length(); i++) //looping through word
        {
            StringBuilder storeWord = new StringBuilder(word); //making word mutable

            for(char let = 'a'; let <= 'z'; let++) //trying all possible combinations between a and z
            {
                storeWord.setCharAt(i, let); //setting that letter to the index of the word
                String wordString = storeWord.toString();
                if(dictionary.contains(wordString.toUpperCase()) && !wordString.equals(word) && !foundWords.contains(wordString)) //Checking if the word exists in the dictionary provided
                {
                        tempWords.push(wordString);
                        foundWords.add(wordString);
                }
            }
        }
        return tempWords;
    }

    /**
     * Takes in the previous stack and goes through it
     * checking if the last word in the ladder is correct
     * and if it isn't it takes it off the stack and tries again
     * @param prev - the previous stack
     * @param check - the word to check
     * @return the queue of stacks of the ladder
     */
    public Queue<Stack<String>> getDupes(Stack<String> prev, String check)
    {
        Queue<Stack<String>> dupes = new LinkedList();
        Stack<String> nextWord = findWords(prev.peek()); //Storing the previous stack of words
        int size = nextWord.size();
        //System.out.println("test: " + nextWord); //test
        for(int i = 0; i < size; i++) //looping through the stack
        {
            Stack<String> temp = new Stack();
            temp.addAll(prev);
            //System.out.println("temp: " + temp); //DONT TEST (LAG)
            if(nextWord.peek().equals(check))  //Checking if they are equal
            {
                temp.push(nextWord.pop());
                dupes.clear();
                dupes.offer(temp); //Stores it since it is a success
                return dupes;
            }
            temp.push(nextWord.pop());
            dupes.offer(temp); //repeat
        }
        return dupes;
    }

    /**
     * Checks if the first word in the ladder is equal to the last
     * and if it is the ladder is found, however if it's not found it
     * goes through queue of stacks and checks for a match
     * @param firstWord - the first word in the ladder
     * @param lastWord - the last word in the ladder
     * @return the stack that either is solved or not solved with the ladder
     */
    public Stack<String> getPath(String firstWord, String lastWord)
    {
            if (firstWord.equals(lastWord)) //if the words to compare are already equal just return it easily
            {
                Stack<String> quick = new Stack<String>();
                quick.push(firstWord);
                System.out.print("Found a ladder! >>> ");
                return quick;
            }
            Queue<Stack<String>> storeWords = new LinkedList<>();
            foundWords = new HashSet();
            foundWords.add(firstWord);
            boolean checkLength = firstWord.length() == lastWord.length();
            Stack<String> temp = new Stack();
            temp.push(firstWord);
            storeWords.offer(temp);

            while (!storeWords.isEmpty() && checkLength && dictionary.contains(firstWord.toUpperCase()) && dictionary.contains(lastWord.toUpperCase())) //makes sure the dictionary actually contains the words given
            {
                storeWords.addAll(getDupes(storeWords.poll(), lastWord)); //calls getDupes method and stores it into the storeWords
                //System.out.println(storeWords); //Test
                if (!storeWords.isEmpty() && storeWords.peek().peek().equals(lastWord)) //If equal we found it!
                {
                    System.out.print("Found a ladder! >>> ");
                    return storeWords.peek();
                }
            }
        System.out.print("No ladder between " + firstWord + " and " + lastWord);
        Stack<String> noLadder = new Stack<String>();
        noLadder.push("!");
        return noLadder;
    }
}
