
import java.io.FileNotFoundException;
import java.util.*;
public class WordLadderRunner
{
    public static void main(String args[]) throws FileNotFoundException
    {
       WordLadder temp = new WordLadder();

    }
}
