import java.util.*;
/**
 * The vertex class defines the abstraction of node on a 2D plane with the x, y and ID while
 * defining the List of edges as a linkedlist
 * @author Michael
 *
 */
public class Vertex implements Comparable<Vertex>
{
	int x, y, ID;
	List<Integer> edges;
	boolean visited;
	double distance;
	Vertex prev;
	/**
	 * Basic constructor that initalizes the ID, x, y and the edges as a LinkedList while making
	 * each distance positive infinity except for the first one which si 0
	 * @param ID - the ID of the vertex
	 * @param x - x coordinate
	 * @param y - y coordinate
	 */
	public Vertex(int ID, int x, int y)
	{
		this.ID = ID;
		this.x = x;
		this.y = y;
		this.edges = new LinkedList<>();
		visited = false;
		this.distance = Double.POSITIVE_INFINITY;
		this.prev = null;
	}
	/**
	 * Adds the edge destination val to the adjacency list
	 * @param d - the destination value
	 */
	public void addE(int d) //destination value
	{
		edges.add(d);
	}
	/**
	 * Gets the euclidian distance with formula from vertex to vertex
	 * @param d - the destination vertex
	 * @return its distance
	 */
	public double euclidDistance(Vertex d) //destination vertex
	{
		return Math.sqrt(Math.pow(d.x - x, 2) + Math.pow(d.y - y, 2));
	}
	/**
	 * Compare to that takes the distance from the given vertex 
	 * distance
	 * @return the int of the subtraction betweeen both distances
	 */
	@Override
	public int compareTo(Vertex obj)
	{
		return (int) (distance - obj.distance);
	}
	/**
	 * To string that prints out the ID of the 
	 * vertices
	 */
	@Override
	public String toString()
	{
		String str = "";
		str = ID + "";
		return str;
	}
}
