import java.util.*;
import java.io.*;
/**
 * This class calculates the shortest path in a given graph between two points
 * @author Michael
 *
 */
public class Dijkstra
{
	static Scanner scan;
	static Graph g;
	static String str;
	static double dist;
	static int counter;
	static int c;
	static ArrayList<Double> arr = new ArrayList<Double>();
	public static void main(String args[])
	{
		try
		{
			scan = new Scanner(new File("input6.txt"));
		}
		catch(Exception e)
		{
			System.out.println("error go brrr");
		}
		g = new Graph(scan);
		int source = 0;
		int destination = 0;
		try
		{
			source = scan.nextInt();
			destination = scan.nextInt();
		} catch (Exception e)
		{
			
		}
		dijkstra(source, destination);
        formatString(dist);
		//System.out.println();
        System.out.println();
        //printShortestPath(g.v[destination]);
        System.out.println("\n" + (double) Math.round(g.v[destination].distance) + "\n");
        System.out.println("Shortest path from " + source + " to " + destination + ":");
        printShortestPath(g.v[destination]);
        System.out.println(str.substring(4, str.length()-3));
        
       // Collections.reverse(arr);
       // System.out.println(arr);

	}
	/**
	 * A private method void that uses
	 * Dijkstra's algorithm to calculate the shortest path and store the results in the Vertex class
	 *	distance field
	 * @param source - the starting point
	 * @param destination - the ending point
	 */
	private static void dijkstra(int source, int destination)
	{
		counter = g.v[destination].ID;
		//System.out.println(counter);
		PriorityQueue<Vertex> succVertex = new PriorityQueue<>();
		g.v[source].distance = 0;
		
		for(int i = 0; i < g.V; i++)
		{
			try
			{
				succVertex.add(g.v[i]);
			} catch (Exception e)
			{
				
			}
			//System.out.println("process node " + g.v[i].ID + " (dist " + (double) Math.round(g.v[i].distance) + ")");
            //arr.add("" + g.v[i].ID);
		}
		
		while(!succVertex.isEmpty())
		{
			Vertex v = succVertex.poll();
			for (Integer n : v.edges) 
			{
                if (!g.v[n].visited)
                {
                    if(v.distance + v.euclidDistance(g.v[n]) < g.v[n].distance)
                    {
                    	g.v[n].distance = v.distance + v.euclidDistance(g.v[n]);
                    	
                    	System.out.println("relaxing: " + (double) Math.round(g.v[n].distance * 10) / 10);
                    	g.v[n].prev = v;
                    }
                	dist =  (g.v[n].distance); //distance
                	arr.add((double) Math.round(g.v[n].distance * 10) / 10);
                }
               // System.out.println(g.v[n].distance);
            }
		}
		System.out.print("process node 0 (dist 0.0)");
	}
	/**
	 * Formats the string very poorly to what is being processed
	 * @param dist - the distance being passed
	 */
	public static void formatString(double dist)
	{
		System.out.println();
    	for(int i = 0; i < arr.size()-1; i++) //g.V
    	{
    			System.out.println("greedily processing " + i + " (dist " + arr.get(i) + ")"); //g.v[i].ID
    	}
		System.out.println(arr);
	}
	
	/**
	 * Prints the shortes path between all the previous vertices
	 * @param vertex - the point
	 * @return the str path
	 */
    public static String printShortestPath(Vertex vertex) 
    {
        if (vertex == null)
        {
        	return "";
        }
        printShortestPath(vertex.prev);
        str += vertex + " -> ";
        return str;
    }
	
}
