import java.util.Scanner;
/**
 * This class represents the graph given by taking the vertices and edges and storying in each 
 * vertex
 * @author Michael
 *
 */
public class Graph
{
	//vertices and edges
	int V, E;
	Vertex[] v; //vertices
	/**
	 * Basic constructor that obtains the vertices and edges and stores it into the adjacency list as a new 
	 * vertex and adds the edges
	 * @param scan - the file given with all the information for the graph
	 */
	public Graph(Scanner scan)
	{
		V = scan.nextInt(); E = scan.nextInt();
		v = new Vertex[V];
		System.out.println(V + " " + E);
		for(int i = 0; i < V; i++)
		{
			try
			{
				int ID = scan.nextInt();
				int x = scan.nextInt();
				int y = scan.nextInt();
				//System.out.println(ID + " " + x + " " + y);
				v[i] = new Vertex(ID, x, y);
			} catch (Exception e)
			{
				
			}
		}
		for(int i = 0; i < E; i++)
		{
			try
			{
				int n = scan.nextInt();
				int n2 = scan.nextInt();
				v[n].addE(n2);
				//System.out.println(n + " " + n2);
			} catch (Exception e)
			{
				
			}
		}
	}
	/**
	 * Returns the distance between two vertices
	 * give the two array indexes
	 * @param from - array index 1 for vertex 1
	 * @param to - array index 2 for vertex 2
	 * @return the distance between the two vertices
	 */
	public double distance(int from, int to)
	{
		return v[from].euclidDistance(v[to]);
	}
}
