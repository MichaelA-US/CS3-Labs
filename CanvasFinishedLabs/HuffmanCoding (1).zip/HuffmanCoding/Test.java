/**
 * This class tests my huffmancoding by taking a file given from the sample txt files and
 * compresses it and then expands it
 * @author Michael
 *
 */
public class Test 
{
    @SuppressWarnings("static-access")
	public static void main(String[] args)
    {
        String txtFileName = "happy hip hop"; //Enter in file name you want here (DONT put .txt after it)
        HuffmanCompressor c = new HuffmanCompressor();
        c.compress("" + txtFileName + ".txt");
        c.expand("" + txtFileName + ".code", "" + txtFileName + ".short", "" + txtFileName + ".new");
        /*
         * Files are generated within the java project itself
         * example: Users/(Username)/(Name of workspace)/(Name of java project)/ <--- File in this path
         */
    }

}
